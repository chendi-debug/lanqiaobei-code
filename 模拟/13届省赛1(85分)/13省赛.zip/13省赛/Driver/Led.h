#include <STC15F2K60S2.H>
void Led_Disp(unsigned char *ucLed);
 void Relay(bit enable);
