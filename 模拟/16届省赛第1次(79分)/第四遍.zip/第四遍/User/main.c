#include <STC15F2K60S2.H>
#include "Key.h"
#include "Led.h"
#include "Seg.h"
#include "Distance.h"	
#include "Init.h"

unsigned char Key_Val,Key_Down,Key_Up,Key_Old;
unsigned char Key_Slow_Down;
unsigned char Seg_Slow_Down;
unsigned char Seg_Buf[8] = {10,10,10,10,10,10,10,10};
unsigned char Seg_Pos;
unsigned char ucLed[8] = {0,0,0,0,0,0,0,0};
unsigned char Dista_Slow_Down;
unsigned int Distance;


void Key_Proc()
{
	if(Key_Slow_Down<10)return;
	Key_Slow_Down = 0;
	
	Key_Val = Key_Read();
	Key_Down = Key_Val & (Key_Old ^ Key_Val);
	Key_Up = ~Key_Val & (Key_Old ^ Key_Val);
	Key_Old = Key_Val;
	
}
void Seg_Proc()
{
	if(Seg_Slow_Down<100)return;
	Seg_Slow_Down = 0;
	
	Seg_Buf[0] = Distance / 100 % 10;
	Seg_Buf[1] = Distance / 10 % 10;
	Seg_Buf[2] = Distance % 10;
	
}

void Led_Proc()
{
	Led_Disp(ucLed);
}

void Distance_Proc()
{
	if(Dista_Slow_Down < 120)return;
		Dista_Slow_Down = 0;
	Distance = Ut_Wave_Data();
	
	
}
void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR &= 0xBF;			//��ʱ��ʱ��12Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x18;				//���ö�ʱ��ʼֵ
	TH1 = 0xFC;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	EA = 1;
}
void Timer1_Isr(void) interrupt 3
{
	Key_Slow_Down++;
	Seg_Slow_Down++;
	Dista_Slow_Down++;
	
	if(++Seg_Pos==8)Seg_Pos = 0;
	if(Seg_Buf[Seg_Pos]>='.')
		Seg_Disp(Seg_Pos,Seg_Buf[Seg_Pos]-'.',1);
	else
		Seg_Disp(Seg_Pos,Seg_Buf[Seg_Pos],0);
		
	
}
void main()
{
  Sys_Init();
//	PCA_Init();
	Timer1_Init();

	while(1)
	{
		Key_Proc();
		Seg_Proc();
		Led_Proc();
		Distance_Proc();
		
	}
}